# Thala 7. Shoe Store

A modern and responsive shoe store landing page.

## Project Structure


Thala-7
│
├── index.html
├── index.css
├── images/
│   ├── shoe.png
│   └── profile.jpg
└── README.md

## How to Run

1. Download or clone the repository.
2. Open the project folder.
3. Open `index.html` in your browser.


